Сборка:  mvn clean package   (нужны JDK 21 и Maven)
Jar: target/AnarchyGuard-1.0.jar -> в папку plugins сервера.
Команды: /ag reload, /ag alerts, /ag vl <игрок>
