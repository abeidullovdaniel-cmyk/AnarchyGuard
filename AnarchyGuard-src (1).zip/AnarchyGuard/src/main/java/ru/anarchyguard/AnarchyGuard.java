package ru.anarchyguard;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Boat;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Shulker;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerVelocityEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class AnarchyGuard extends JavaPlugin implements Listener {

    /** Данные игрока. Только примитивы и мелкие коллекции - без лишних аллокаций в onMove. */
    private static final class Data {
        final Map<String, Double> vl = new HashMap<>(4);
        final Map<String, Long> lastAlert = new HashMap<>(4);
        boolean bypass;

        // безопасная позиция (примитивы, чтобы не клонировать Location каждый тик)
        World safeWorld;
        double safeX, safeY, safeZ;
        boolean hasSafe;

        long graceUntil, flagUntil;
        double groundY;
        int hover, speedBuf, spoof;

        // NoFall
        double fall;
        boolean entityGround;
        boolean pendingNoFall;
        long landTime, lastFallDamage;
        double landFall;

        // KillAura
        final ArrayDeque<Long> hits = new ArrayDeque<>();
        UUID lastTarget;
        long lastHitTime;
        double bigRot;
        long bigRotTime;

        void resetAir() {
            hover = 0;
            speedBuf = 0;
            spoof = 0;
            fall = 0;
        }
    }

    private final Map<UUID, Data> data = new HashMap<>();
    private final Set<UUID> alertsOff = new HashSet<>();
    private volatile double tps = 20.0;

    // ---- кэш настроек ----
    private double minTps, vlDecay, setbackVl, kickVl;
    private int maxPing, alertCooldown, joinGrace;
    private boolean flyOn, speedOn, reachOn;
    private int maxHover, speedBuffer;
    private double heightLeeway, maxHorizontal, maxReach;
    private boolean auraOn, auraWall, auraSnap, auraHitbox;
    private int auraMaxHits;
    private double auraExpand, auraSnapAngle;
    private boolean nofallOn, nofallSpoof, nofallDamage;
    private int spoofTicks;
    private double nofallMinFall;
    private String prefix, alertMsg, kickMsg;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadSettings();
        Bukkit.getPluginManager().registerEvents(this, this);

        // раз в секунду: TPS, права bypass, затухание VL (всё остальное - без опросов в onMove)
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            double[] t = Bukkit.getTPS();
            if (t.length > 0) tps = t[0];
            for (Player p : Bukkit.getOnlinePlayers()) {
                Data d = data.get(p.getUniqueId());
                if (d == null) continue;
                d.bypass = p.hasPermission("anarchyguard.bypass");
                if (!d.vl.isEmpty()) {
                    d.vl.entrySet().removeIf(en -> {
                        double v = en.getValue() - vlDecay;
                        if (v <= 0) return true;
                        en.setValue(v);
                        return false;
                    });
                }
            }
        }, 20L, 20L);
        getLogger().info("AnarchyGuard включён.");
    }

    private void loadSettings() {
        reloadConfig();
        var c = getConfig();
        minTps = c.getDouble("min-tps", 16.0);
        maxPing = c.getInt("max-ping", 350);
        vlDecay = c.getDouble("vl-decay", 0.6);
        setbackVl = c.getDouble("setback-vl", 6.0);
        kickVl = c.getDouble("kick-vl", 25.0);
        alertCooldown = c.getInt("alert-cooldown-ms", 1500);
        joinGrace = c.getInt("join-grace-ms", 3000);

        flyOn = c.getBoolean("checks.fly.enabled", true);
        maxHover = c.getInt("checks.fly.max-hover-ticks", 12);
        heightLeeway = c.getDouble("checks.fly.height-leeway", 0.4);

        speedOn = c.getBoolean("checks.speed.enabled", true);
        maxHorizontal = c.getDouble("checks.speed.max-horizontal", 0.85);
        speedBuffer = c.getInt("checks.speed.buffer", 5);

        reachOn = c.getBoolean("checks.reach.enabled", true);
        maxReach = c.getDouble("checks.reach.max-distance", 3.8);

        auraOn = c.getBoolean("checks.killaura.enabled", true);
        auraMaxHits = c.getInt("checks.killaura.max-hits-per-second", 22);
        auraHitbox = c.getBoolean("checks.killaura.hitbox-check", true);
        auraExpand = c.getDouble("checks.killaura.hitbox-expand", 0.4);
        auraWall = c.getBoolean("checks.killaura.wall-check", true);
        auraSnap = c.getBoolean("checks.killaura.snap-check", true);
        auraSnapAngle = c.getDouble("checks.killaura.snap-angle", 130.0);

        nofallOn = c.getBoolean("checks.nofall.enabled", true);
        nofallSpoof = c.getBoolean("checks.nofall.spoof-check", true);
        spoofTicks = c.getInt("checks.nofall.spoof-ticks", 3);
        nofallDamage = c.getBoolean("checks.nofall.damage-check", true);
        nofallMinFall = c.getDouble("checks.nofall.min-fall-distance", 4.5);

        prefix = c.getString("messages.prefix", "&c[AG] &f");
        alertMsg = c.getString("messages.alert", "&e%player% &fзаподозрен в &c%check% &7(%info%) &fVL: &c%vl%");
        kickMsg = c.getString("messages.kick", "&cВы были кикнуты античитом.");
    }

    // ================= утилиты =================

    private Data data(Player p) {
        return data.computeIfAbsent(p.getUniqueId(), k -> new Data());
    }

    private Component color(String s) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(s);
    }

    private void grace(Data d, long ms) {
        d.graceUntil = Math.max(d.graceUntil, System.currentTimeMillis() + ms);
        d.resetAir();
    }

    private static void setSafe(Data d, World w, Location l) {
        d.safeWorld = w;
        d.safeX = l.getX();
        d.safeY = l.getY();
        d.safeZ = l.getZ();
        d.hasSafe = true;
    }

    /** Дёшево: никаких опросов сервера (TPS и bypass кэшируются раз в секунду). */
    private boolean skip(Player p, Data d) {
        if (d.bypass || tps < minTps) return true;
        GameMode gm = p.getGameMode();
        if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) return true;
        if (p.getAllowFlight() || p.isFlying() || p.isInsideVehicle() || p.isDead()) return true;
        return p.getPing() > maxPing;
    }

    private void flag(Player p, Data d, String check, double add, String info) {
        long now = System.currentTimeMillis();
        double v = d.vl.merge(check, add, Double::sum);
        d.flagUntil = now + 3000;

        if (now - d.lastAlert.getOrDefault(check, 0L) >= alertCooldown) {
            d.lastAlert.put(check, now);
            Component c = color(prefix + alertMsg
                    .replace("%player%", p.getName())
                    .replace("%check%", check)
                    .replace("%info%", info)
                    .replace("%vl%", String.format("%.1f", v)));
            for (Player op : Bukkit.getOnlinePlayers()) {
                if (op.hasPermission("anarchyguard.alerts") && !alertsOff.contains(op.getUniqueId())) {
                    op.sendMessage(c);
                }
            }
            Bukkit.getConsoleSender().sendMessage(c);
        }

        if (v >= kickVl) {
            d.vl.clear();
            p.kick(color(kickMsg));
        } else if (v >= setbackVl && d.hasSafe && d.safeWorld != null) {
            Location cur = p.getLocation();
            p.teleport(new Location(d.safeWorld, d.safeX, d.safeY, d.safeZ, cur.getYaw(), cur.getPitch()),
                    PlayerTeleportEvent.TeleportCause.PLUGIN);
            grace(d, 500);
        }
    }

    /** Есть ли твёрдый блок под ногами на заданном смещении. Незагруженные чанки считаем твёрдыми (не грузим их). */
    private boolean solidBelow(World w, double x, double y, double z, double off) {
        int by = (int) Math.floor(y + off);
        int x0 = (int) Math.floor(x - 0.3), x1 = (int) Math.floor(x + 0.3);
        int z0 = (int) Math.floor(z - 0.3), z1 = (int) Math.floor(z + 0.3);
        for (int bx = x0; bx <= x1; bx++) {
            for (int bz = z0; bz <= z1; bz++) {
                if (!w.isChunkLoaded(bx >> 4, bz >> 4)) return true;
                if (!w.getBlockAt(bx, by, bz).isPassable()) return true;
            }
        }
        return false;
    }

    private boolean entityBelow(Location loc) {
        return !loc.getWorld().getNearbyEntities(loc, 1.2, 1.0, 1.2,
                en -> en instanceof Boat || en instanceof Shulker).isEmpty();
    }

    private static boolean mediumBlock(Material m) {
        switch (m) {
            case WATER, LAVA, COBWEB, POWDER_SNOW, HONEY_BLOCK, SLIME_BLOCK, BUBBLE_COLUMN,
                 SCAFFOLDING, SWEET_BERRY_BUSH, BIG_DRIPLEAF, POINTED_DRIPSTONE:
                return true;
            default:
                return Tag.CLIMBABLE.isTagged(m) || Tag.BEDS.isTagged(m);
        }
    }

    /** Среда, где обычная физика не работает. Вызывается только когда игрок в воздухе. */
    private boolean specialMedium(Player p, Location loc) {
        if (p.isInWater()) return true;
        World w = loc.getWorld();
        int x = loc.getBlockX(), y = loc.getBlockY(), z = loc.getBlockZ();
        return mediumBlock(w.getBlockAt(x, (int) Math.floor(loc.getY() - 0.5), z).getType())
                || mediumBlock(w.getBlockAt(x, y, z).getType())
                || mediumBlock(w.getBlockAt(x, y + 1, z).getType());
    }

    private Material blockUnder(Location l) {
        return l.getWorld().getBlockAt(l.getBlockX(), (int) Math.floor(l.getY() - 0.5), l.getBlockZ()).getType();
    }

    private int amp(Player p, PotionEffectType t) {
        PotionEffect e = p.getPotionEffect(t);
        return e == null ? -1 : e.getAmplifier();
    }

    // ================= движение =================

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Location from = e.getFrom();
        Location to = e.getTo();
        if (to == null) return;
        Player p = e.getPlayer();
        Data d = data(p);

        // резкие повороты камеры (для KillAura Snap)
        if (auraOn && auraSnap) {
            double yawD = Math.abs(((to.getYaw() - from.getYaw()) % 360 + 540) % 360 - 180);
            double rot = Math.hypot(yawD, Math.abs(to.getPitch() - from.getPitch()));
            if (rot > auraSnapAngle) {
                d.bigRot = rot;
                d.bigRotTime = System.currentTimeMillis();
            }
        }

        double dx = to.getX() - from.getX();
        double dy = to.getY() - from.getY();
        double dz = to.getZ() - from.getZ();
        if (dx == 0 && dy == 0 && dz == 0) return;   // только поворот головы
        World w = to.getWorld();
        if (w != from.getWorld()) return;

        long now = System.currentTimeMillis();
        if (skip(p, d)) {
            d.resetAir();
            setSafe(d, w, to);
            return;
        }

        boolean ground = solidBelow(w, to.getX(), to.getY(), to.getZ(), -0.1);
        d.entityGround = false;
        // лодки/шалкеры проверяем только если игрок почти не двигается по вертикали
        if (!ground && dy > -0.1 && dy < 0.1 && entityBelow(to)) {
            ground = true;
            d.entityGround = true;
        }

        if (now < d.graceUntil || p.isGliding() || p.isRiptiding() || p.isClimbing() || p.isSwimming()
                || (!ground && specialMedium(p, to))) {
            d.resetAir();
            d.groundY = to.getY();
            if (ground) setSafe(d, w, to);
            return;
        }

        if (ground) {
            if (d.fall > 0) {
                onLanding(p, d, to, now);
                d.fall = 0;
            }
            d.groundY = to.getY();
            d.hover = 0;
            d.spoof = 0;
            if (now > d.flagUntil) setSafe(d, w, to);
        } else {
            if (dy < 0) d.fall -= dy;
            if (nofallOn && nofallSpoof) checkSpoof(p, d, to);
            if (flyOn) checkFly(p, d, to, dy);
        }

        if (speedOn) {
            double h = Math.hypot(dx, dz);
            double limit = maxHorizontal;
            boolean over = false;
            if (h > maxHorizontal) {          // тяжёлые расчёты только при подозрении
                limit = speedLimit(p, to);
                over = h > limit;
            }
            if (over) {
                if (++d.speedBuf >= speedBuffer) {
                    flag(p, d, "Speed", 1.0, String.format("%.2f > %.2f", h, limit));
                    d.speedBuf = 0;
                }
            } else if (d.speedBuf > 0) {
                d.speedBuf--;
            }
        }
    }

    private double speedLimit(Player p, Location to) {
        double limit = maxHorizontal;
        int sp = amp(p, PotionEffectType.SPEED);
        if (sp >= 0) limit *= 1.0 + 0.2 * (sp + 1);
        double ws = p.getWalkSpeed() / 0.2;
        if (ws > 1.0) limit *= ws;
        Material under = blockUnder(to);
        if (Tag.ICE.isTagged(under)) limit *= 1.8;
        else if (under == Material.SOUL_SAND || under == Material.SOUL_SOIL) limit *= 1.5;
        return limit;
    }

    private void checkFly(Player p, Data d, Location to, double dy) {
        if (p.hasPotionEffect(PotionEffectType.LEVITATION) || p.hasPotionEffect(PotionEffectType.SLOW_FALLING)) {
            d.hover = 0;
            return;
        }
        double maxRise = 1.25 + heightLeeway;
        int jump = amp(p, PotionEffectType.JUMP_BOOST);
        if (jump >= 0) maxRise += 0.55 * (jump + 1) + 0.15 * (jump + 1) * (jump + 1);
        double rise = to.getY() - d.groundY;
        if (rise > maxRise) {
            flag(p, d, "Fly", 2.0, String.format("высота +%.2f", rise));
        }
        if (dy > -0.03 && dy < 0.03) {
            if (++d.hover > maxHover) {
                flag(p, d, "Fly", 1.5, "зависание");
                d.hover = 0;
            }
        } else if (d.hover > 0) {
            d.hover--;
        }
    }

    // ================= NoFall =================

    /** Клиент говорит "я на земле", хотя под ним явно воздух. */
    @SuppressWarnings("deprecation")
    private void checkSpoof(Player p, Data d, Location to) {
        if (p.isOnGround() && clearlyAirborne(to)) {
            if (++d.spoof >= spoofTicks) {
                flag(p, d, "NoFall", 1.5, "ложный onGround");
                d.spoof = 0;
            }
        } else if (d.spoof > 0) {
            d.spoof--;
        }
    }

    private boolean clearlyAirborne(Location l) {
        World w = l.getWorld();
        double x = l.getX(), y = l.getY(), z = l.getZ();
        return !solidBelow(w, x, y, z, -0.1) && !solidBelow(w, x, y, z, -0.6)
                && !solidBelow(w, x, y, z, -1.1) && !entityBelow(l);
    }

    /** Приземление: бонус-грация на слайме/кроватях и отложенная проверка "был ли урон от падения". */
    private void onLanding(Player p, Data d, Location to, long now) {
        Material below = blockUnder(to);
        if (below == Material.SLIME_BLOCK || Tag.BEDS.isTagged(below)) {
            d.graceUntil = Math.max(d.graceUntil, now + 4000);   // отскок
            return;
        }
        if (!nofallOn || !nofallDamage) return;
        double fall = d.fall;
        if (fall < nofallMinFall || d.entityGround) return;
        if (below == Material.HAY_BLOCK || below == Material.HONEY_BLOCK || below == Material.SCAFFOLDING
                || below == Material.COBWEB || below == Material.POWDER_SNOW
                || below == Material.SWEET_BERRY_BUSH || Tag.CLIMBABLE.isTagged(below)) return;
        if (p.getNoDamageTicks() > 0 || p.isInvulnerable() || fallProtected(p, fall)) return;

        d.pendingNoFall = true;
        d.landTime = now;
        d.landFall = fall;
        Bukkit.getScheduler().runTaskLater(this, () -> verifyFall(p), 4L);
    }

    private boolean fallProtected(Player p, double fall) {
        if (p.hasPotionEffect(PotionEffectType.SLOW_FALLING)) return true;
        if (amp(p, PotionEffectType.RESISTANCE) >= 4) return true;
        int jb = amp(p, PotionEffectType.JUMP_BOOST);
        if (jb >= 0) fall -= jb + 1;
        ItemStack boots = p.getInventory().getBoots();
        if (boots != null && boots.getType() != Material.AIR) {
            fall -= boots.getEnchantmentLevel(Enchantment.FEATHER_FALLING) * 0.75;
        }
        return fall < nofallMinFall;
    }

    private void verifyFall(Player p) {
        if (!p.isOnline()) return;
        Data d = data.get(p.getUniqueId());
        if (d == null || !d.pendingNoFall) return;
        d.pendingNoFall = false;
        if (d.bypass || p.isDead() || d.lastFallDamage >= d.landTime - 100) return;
        flag(p, d, "NoFall", 2.5, String.format("упал %.1f бл. без урона", d.landFall));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDamage(EntityDamageEvent e) {
        if (e.getCause() == EntityDamageEvent.DamageCause.FALL && e.getEntity() instanceof Player p) {
            Data d = data.get(p.getUniqueId());
            if (d != null) d.lastFallDamage = System.currentTimeMillis();
        }
    }

    // ================= бой: Reach + KillAura =================

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p)) return;
        if (e.getCause() != EntityDamageEvent.DamageCause.ENTITY_ATTACK) return;
        Data d = data(p);
        if (skip(p, d)) return;

        Entity target = e.getEntity();
        BoundingBox box = target.getBoundingBox();
        Location eye = p.getEyeLocation();
        double cx = Math.max(box.getMinX(), Math.min(eye.getX(), box.getMaxX()));
        double cy = Math.max(box.getMinY(), Math.min(eye.getY(), box.getMaxY()));
        double cz = Math.max(box.getMinZ(), Math.min(eye.getZ(), box.getMaxZ()));
        Vector closest = new Vector(cx, cy, cz);
        double dist = closest.distance(eye.toVector());

        if (reachOn && dist > maxReach) {
            e.setCancelled(true);
            flag(p, d, "Reach", 1.5, String.format("%.2f блока", dist));
            return;
        }
        if (auraOn && killAura(p, d, target, eye, box, closest, dist)) {
            e.setCancelled(true);
        }
    }

    /** @return true, если удар надо отменить */
    private boolean killAura(Player p, Data d, Entity target, Location eye,
                             BoundingBox box, Vector closest, double dist) {
        long now = System.currentTimeMillis();
        boolean cancel = false;

        // 1) Multi-Aura: разные цели быстрее одного тика
        UUID tid = target.getUniqueId();
        if (d.lastTarget != null && !d.lastTarget.equals(tid) && now - d.lastHitTime < 40) {
            flag(p, d, "KillAura", 3.0, "Multi (несколько целей за тик)");
            cancel = true;
        }
        d.lastTarget = tid;
        d.lastHitTime = now;

        // 2) Частота ударов
        d.hits.addLast(now);
        while (!d.hits.isEmpty() && now - d.hits.peekFirst() > 1000) d.hits.pollFirst();
        if (d.hits.size() > auraMaxHits) {
            flag(p, d, "KillAura", 2.0, "ударов/сек: " + d.hits.size());
            cancel = true;
        }

        // 3) Hitbox (запас растёт с пингом)
        Vector eyeVec = eye.toVector();
        Vector look = eye.getDirection();
        if (auraHitbox) {
            double expand = auraExpand + Math.min(p.getPing(), 300) / 50.0 * 0.1;
            if (box.clone().expand(expand).rayTrace(eyeVec, look, dist + 2.0) == null) {
                flag(p, d, "KillAura", 2.0, "Hitbox (бьёт не глядя на цель)");
                cancel = true;
            }
        }

        // 4) Snap: резкий доворот перед ударом + точное наведение
        if (auraSnap && now - d.bigRotTime < 100) {
            Vector toCenter = box.getCenter().subtract(eyeVec);
            if (toCenter.lengthSquared() > 0.0001
                    && Math.toDegrees(look.angle(toCenter.normalize())) < 8.0) {
                flag(p, d, "KillAura", 0.75, String.format("Snap (%.0f°)", d.bigRot));
            }
        }

        // 5) Wall: удар через твёрдые блоки
        if (auraWall && dist > 0.5) {
            Vector dir = closest.clone().subtract(eyeVec).normalize();
            RayTraceResult br = p.getWorld().rayTraceBlocks(eye, dir, dist, FluidCollisionMode.NEVER, true);
            if (br != null && br.getHitPosition().distance(eyeVec) < dist - 0.3) {
                flag(p, d, "KillAura", 2.0, "Wall (удар через блок)");
                cancel = true;
            }
        }
        return cancel;
    }

    // ================= прочие события =================

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Data d = data(p);
        d.bypass = p.hasPermission("anarchyguard.bypass");
        grace(d, joinGrace);
    }

    @EventHandler
    public void onVelocity(PlayerVelocityEvent e) {
        grace(data(e.getPlayer()), 2500);   // взрывы, wind charge, отбрасывание
    }

    @EventHandler
    public void onTeleport(PlayerTeleportEvent e) {
        Data d = data(e.getPlayer());
        grace(d, 1500);
        Location t = e.getTo();
        if (t != null) setSafe(d, t.getWorld(), t);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        grace(data(e.getPlayer()), 1500);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        data.remove(e.getPlayer().getUniqueId());
        alertsOff.remove(e.getPlayer().getUniqueId());
    }

    // ================= команды =================

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] args) {
        if (!s.hasPermission("anarchyguard.admin")) {
            s.sendMessage(color("&cНет прав."));
            return true;
        }
        String help = prefix + "/ag reload | /ag alerts | /ag vl <игрок>";
        if (args.length == 0) {
            s.sendMessage(color(help));
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "reload" -> {
                loadSettings();
                s.sendMessage(color(prefix + "Конфиг перезагружен."));
            }
            case "alerts" -> {
                if (s instanceof Player p) {
                    if (alertsOff.remove(p.getUniqueId())) {
                        s.sendMessage(color(prefix + "Оповещения &aвключены"));
                    } else {
                        alertsOff.add(p.getUniqueId());
                        s.sendMessage(color(prefix + "Оповещения &cвыключены"));
                    }
                }
            }
            case "vl" -> {
                if (args.length < 2) {
                    s.sendMessage(color(help));
                    return true;
                }
                Player t = Bukkit.getPlayerExact(args[1]);
                Data d = t == null ? null : data.get(t.getUniqueId());
                if (d == null) {
                    s.sendMessage(color(prefix + "Игрок не найден."));
                } else if (d.vl.isEmpty()) {
                    s.sendMessage(color(prefix + t.getName() + ": нарушений нет."));
                } else {
                    StringBuilder sb = new StringBuilder(prefix + t.getName() + ": ");
                    d.vl.forEach((k, v) -> sb.append("&e").append(k).append("&f=").append(String.format("%.1f", v)).append(" "));
                    s.sendMessage(color(sb.toString()));
                }
            }
            default -> s.sendMessage(color(help));
        }
        return true;
    }
}
